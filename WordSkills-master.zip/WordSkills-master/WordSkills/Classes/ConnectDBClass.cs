﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordSkills.Classes
{
    internal class ConnectDBClass
    {
        public static Models.BlagodatAlibekov195Entities modelDB;

    }
}
